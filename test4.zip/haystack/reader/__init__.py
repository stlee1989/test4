from haystack.reader.farm import FARMReader
from haystack.reader.transformers import TransformersReader
