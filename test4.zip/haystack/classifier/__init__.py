from haystack.classifier.farm import FARMClassifier
