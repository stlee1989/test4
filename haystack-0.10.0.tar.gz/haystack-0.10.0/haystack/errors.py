# coding: utf8
"""Custom Errors for Haystack stacks"""


class DuplicateDocumentError(ValueError):
    """Exception for Duplicate document"""
    pass
