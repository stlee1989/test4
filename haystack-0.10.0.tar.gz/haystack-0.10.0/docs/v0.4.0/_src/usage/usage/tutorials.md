# Tutorials

## 1) Start using Haystack to search through your own documents

> Make this a button?

> A link-  .. ref:: 1) Start using Haystack to search through your own documents

## 2) Make Haystack understand your jargon

## 3) Connect Haystack to your Datastore of choice

## 4) Answer incoming questions using FAQ pages

## 5) Benchmark the different components of Haystack

## 6) SoTA: Powerup Haystack with DPR
