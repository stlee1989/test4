Tutorials
====================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   1) Using Haystack to search through your own documents <tutorials/1>
   2) Make Haystack understand your jargon <tutorials/2>
   3) Connect Haystack to your Datastore of choice <tutorials/3>
   4) Answer incoming questions using FAQ pages <tutorials/4>
   5) Benchmark the different components of Haystack <tutorials/5>
   6) SoTA: Powerup Haystack with DPR <tutorials/6>
