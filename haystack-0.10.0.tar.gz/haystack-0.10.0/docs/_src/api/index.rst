.. Haystack documentation master file, created by
   sphinx-quickstart on Tue Jul 28 14:14:55 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   api/database
   api/retriever
   api/reader
   api/indexing
   api/rest_api
   api/file_converters
   api/finder
