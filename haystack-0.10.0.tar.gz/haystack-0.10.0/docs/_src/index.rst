.. toctree::
        :caption: Usage
        :maxdepth: 3
        :numbered:

        usage/index

.. toctree::
        :caption: Tutorials
        :maxdepth: 3
        :numbered:

        tutorials/index

.. toctree::
        :caption: API
        :maxdepth: 3
        :numbered:

        api/index

