__version__ = '1.6.0+cpu'
debug = False
cuda = None
git_version = 'b31f58de6fa8bbda5353b3c77d9be4914399724d'
hip = None
