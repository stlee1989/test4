# this is for historical pickle deserilaization, it is not used otherwise

def _get_thnn_function_backend():
    pass
