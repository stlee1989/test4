# torchvision imports tqdm from here.
from torch.hub import tqdm, load_state_dict_from_url as load_url  # noqa: F401
